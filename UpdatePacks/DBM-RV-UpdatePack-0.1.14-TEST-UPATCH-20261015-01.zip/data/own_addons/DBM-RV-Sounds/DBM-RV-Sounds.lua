local addonName = ...
if not LibStub then return end

local LSM = LibStub("LibSharedMedia-3.0", true)
if not LSM then return end

-- Redistributable alert media from SharedMedia: AlertMediaPack 1.0.0.
-- Per-file licensing and attribution: THIRD_PARTY_NOTICES.txt + Licenses/.
local sounds = {
	{"Air Horn", "AirHorn.ogg"},
	{"Applause", "Applause.ogg"},
	{"Blast", "Blast.ogg"},
	{"Bleat", "Bleat.ogg"},
	{"Boxing Arena Gong", "BoxingArenaSound.ogg"},
	{"Cartoon Voice Baritone", "CartoonVoiceBaritone.ogg"},
	{"Cartoon Walking", "CartoonWalking.ogg"},
	{"Cat Meow", "CatMeow2.ogg"},
	{"Cow Mooing", "CowMooing.ogg"},
	{"Heartbeat Single", "HeartbeatSingle.ogg"},
	{"Kitten Meow", "KittenMeow.ogg"},
	{"Lossa Healer Trinket", "LossaHealerTrinket.ogg"},
	{"Lossa Trinket", "LossaTrinket.ogg"},
	{"Ringing Phone", "RingingPhone.ogg"},
	{"Roaring Lion", "RoaringLion.ogg"},
	{"Robot Blip", "RobotBlip.ogg"},
	{"Shotgun", "Shotgun.ogg"},
	{"Temple Bell", "TempleBellHuge.ogg"},
	{"Torch", "Torch.ogg"},
	{"Warning Siren", "WarningSiren.ogg"},
	{"Water Drop", "WaterDrop.ogg"},
}

for _, entry in ipairs(sounds) do
	LSM:Register("sound", entry[1], [[Interface\AddOns\DBM-RV-Sounds\Sounds\]] .. entry[2])
end

-- Compatibility aliases for two previously exposed selectable names.
-- No historical unresolved OGG bytes are retained.
LSM:Register("sound", "Cat", [[Interface\AddOns\DBM-RV-Sounds\Sounds\CatMeow2.ogg]])
LSM:Register("sound", "Phone", [[Interface\AddOns\DBM-RV-Sounds\Sounds\RingingPhone.ogg]])

-- Stock WoW 7.3.5 client sounds: no bundled audio files required.
LSM:Register("sound", "Lich King Apocalypse", [[Sound\Creature\LichKing\IC_Lich King_Special01.ogg]])
LSM:Register("sound", "You Fail!", [[Sound\Creature\Kologarn\UR_Kologarn_Slay02.ogg]])
LSM:Register("sound", "You Will Die!", [[Sound\Creature\CThun\CThunYouWillDIe.ogg]])
