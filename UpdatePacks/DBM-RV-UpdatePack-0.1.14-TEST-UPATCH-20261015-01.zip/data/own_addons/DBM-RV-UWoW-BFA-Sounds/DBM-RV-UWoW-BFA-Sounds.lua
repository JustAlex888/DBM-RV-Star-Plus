-- DBM-RV UWoW 7.3.5 — BFA Sounds Addon
-- No audio files are bundled here.
-- These entries point only to sound assets already present in the user's WoW client.

DBM_RV_BFA_EXTRA_SOUNDS = {
	{text = "Lich King: Apocalypse", value = [[Sound\Creature\LichKing\IC_Lich King_Special01.ogg]]},
	{text = "Kologarn: You Fail!", value = [[Sound\Creature\Kologarn\UR_Kologarn_Slay02.ogg]]},
	{text = "C'Thun: You Will Die!", value = [[Sound\Creature\CThun\CThunYouWillDIe.ogg]]},
	{text = "Lady Malande: Flee", value = [[Sound\Creature\LadyMalande\BLCKTMPLE_LadyMal_Aggro01.ogg]]},
	{text = "Millhouse: Light You Up", value = [[Sound\Creature\MillhouseManastorm\TEMPEST_Millhouse_Pyro01.ogg]]},
}

-- Separate-package adapter: expose these existing client paths to unchanged DBM-GUI.
local media=LibStub and LibStub("LibSharedMedia-3.0",true)
if media then
	for _,entry in ipairs(DBM_RV_BFA_EXTRA_SOUNDS) do
		media:Register("sound",entry.text,entry.value)
	end
end
