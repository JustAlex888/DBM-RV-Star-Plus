-- Separate compatibility layer; no DBM-Core prototype or persistent option changes.
-- Original DBM / DBM-RV copyright and authorship remain with their respective authors.
local addonName = ...
local VERSION = "0.1.17 TEST"
local BUILD = "UPATCH-20261107-01"
local UPSTREAM = "e97f138de7d3ba846e8a2ee36a35730831e04e27"
local API = {version = VERSION, build = BUILD, upstream = UPSTREAM, status = {}, installed = {}, endHooks = {}}
if _G.DBMRVUWoWCompat then return end -- Do not install a second layer over a running one.
_G.DBMRVUWoWCompat = API
local frame = CreateFrame("Frame")
local window, textBox

-- UX-001 / GAME_TEST_003-005:
-- User decision after GAME_TEST_005: suppress only Aleksart's exact post-encounter
-- DBM_FORUMS_MESSAGE block. Do not touch normal DBM warnings, announces, timers or chat output.
-- Implemented in the companion layer so DBM-Core remains byte-identical to upstream.
local forumHookInstalled = false
local function installForumMessageHook()
	local core = _G.DBM
	if forumHookInstalled or not core or type(core.AddMsg) ~= "function" then return end
	local originalAddMsg = core.AddMsg
	core.AddMsg = function(self, text, prefix)
		local forumMessage = _G.DBM_FORUMS_MESSAGE
		if forumMessage and text == forumMessage then
			return
		end
		return originalAddMsg(self, text, prefix)
	end
	forumHookInstalled = true
	API.forumMessageHook = "ACTIVE / SUPPRESSED"
end
local function findOne(list, field, value)
	local found
	for _, obj in ipairs(list or {}) do
		if obj[field] == value then
			if found then return nil end
			found = obj
		end
	end
	return found
end
local refresh
local function deferUntilEnd(id,mod)
	if API.endHooks[id]==mod then return end
	local original=mod.OnCombatEnd
	mod.OnCombatEnd=function(self,...)
		if original then original(self,...) end
		refresh() -- Core has completed Stop and cleared inCombat before this callback.
	end
	API.endHooks[id]=mod
end
refresh=function()
	local _, _, _, interface = GetBuildInfo()
	local core = _G.DBM
	if interface ~= 70300 or not core or core.Revision ~= 17752 or core.ReleaseRevision ~= 17751 or core.BFAPatchVersion ~= nil then
		API.base = "INCOMPATIBLE"
		return
	end
	-- This is a runtime metadata/capability check, not a cryptographic source-file check.
	API.base = "SUPPORTED_METADATA; verify installed hashes offline"
	for _, id in ipairs({"1783", "1982", "1984", "2031"}) do
		local mod = core:GetModByName(id)
		if not mod then
			API.status[id] = "WAITING_FOR_MODULE"
		elseif API.installed[id] == mod then
			API.status[id] = "ACTIVE"
		elseif mod.inCombat then
			API.status[id] = "DEFERRED / UNPROTECTED_THIS_COMBAT"
			deferUntilEnd(id,mod)
		elseif id == "1783" then
			-- RVFIX-012: one timer instance, not timerPrototype and not other AI timers.
			local timer = findOne(mod.timers, "id", "Timer219591ai")
			if not timer or type(timer.Start) ~= "function" or (timer.start and timer.start ~= timer.Start) then
				API.status[id] = "INCOMPATIBLE_TIMER"
			else
				timer.start = timer.Start
				API.installed[id], API.status[id] = mod, "ACTIVE"
			end
		elseif id == "1982" then
			-- RVFIX-062: retain the original removal handler and cancel only Backlash fades.
			local cd = findOne(mod.countdowns, "id", "CountdownFades247816")
			local original = mod.SPELL_AURA_REMOVED
			if not cd or type(cd.Cancel) ~= "function" or type(original) ~= "function" then
				API.status[id] = "INCOMPATIBLE_COUNTDOWN"
			else
				mod.SPELL_AURA_REMOVED = function(self, args, ...)
					original(self, args, ...)
					if args.spellId == 247816 then cd:Cancel() end
				end
				API.installed[id], API.status[id] = mod, "ACTIVE"
			end
		else
			-- SUP-SAFETY: only the explicitly prepared local entry point of the two modules.
			if mod.__UWoWCompatSourceRevision ~= 1 then
				API.status[id] = "MISSING_REQUIRED_REPLACEMENT"
			else
				mod.__UWoWLegacyPremsgBlocked = true
				API.installed[id], API.status[id] = mod, "ACTIVE"
			end
		end
	end
end
API.Refresh = refresh
local function component(name)
	local installed = GetAddOnInfo(name)
	if not installed then return "NOT INSTALLED" end
	return IsAddOnLoaded(name) and "LOADED" or "INSTALLED / LOAD ON DEMAND"
end
local function statusText()
	refresh()
	local ru = GetLocale() == "ruRU"
	local lines = {
		"DBM-RV UWoW Compatibility Pack "..VERSION,
		"Build: "..BUILD,
		ru and "Оригинальный DBM и DBM-RV — продукты исходных авторов и Aleksart163." or "Original DBM and DBM-RV remain products of their authors and Aleksart163.",
		"https://github.com/Aleksart163/DBM-RV-LEG",
		"Supported upstream commit: "..UPSTREAM,
		"Base: "..tostring(API.base),
		ru and "Послебоссовый блок Aleksart DBM_FORUMS_MESSAGE: подавляется компаньоном; остальные сообщения DBM не затрагиваются." or "Aleksart post-boss DBM_FORUMS_MESSAGE block: suppressed by the companion; other DBM messages are untouched.",
		ru and "Логово Нелтариона: GAME_TEST_004 timer/warning adjustments = INSTALLED / READY_FOR_TEST." or "Neltharion's Lair: GAME_TEST_004 timer/warning adjustments = INSTALLED / READY_FOR_TEST.",
		"Nazak / RVFIX-012: "..tostring(API.status["1783"] or "NOT CHECKED"),
		"Lura / RVFIX-062: "..tostring(API.status["1982"] or "NOT CHECKED"),
		"Aggramar / TEST containment: "..tostring(API.status["1984"] or "NOT CHECKED"),
		"Argus / TEST containment: "..tostring(API.status["2031"] or "NOT CHECKED"),
		"BFA (Freehold / Underrot): "..component("DBM-Party-BfA"),
		"WoD (Everbloom / Grimrail / SMBG): "..component("DBM-Party-WoD"),
		ru and "Пакет содержит физические замены. Отключение компаньона не восстанавливает исходники." or "This patch includes physical replacements. Disabling this companion does not restore original files.",
		ru and "Runtime-проверка метаданных не проверяет SHA-256 установленных файлов." or "Runtime metadata checks do not verify installed file SHA-256 hashes.",
		ru and "TEST: игровой тест ещё нужен. Причина hard-freeze не установлена. P2-вопросы открыты." or "TEST: in-game verification is still required. Hard-freeze cause is not established; P2 questions remain open.",
		ru and "Для отчёта: build, сложность, роль, босс/способность, время и BugGrabber/логи." or "Report build, difficulty, role, boss/spell, timestamps and BugGrabber/logs.",
	}
	return table.concat(lines, "\n\n")
end
function API.Show()
	if not window then
		if _G.DBMRVUWoWCompatStatus then return end
		window = CreateFrame("Frame", "DBMRVUWoWCompatStatus", UIParent)
		window:SetSize(640, 520); window:SetPoint("CENTER"); window:SetFrameStrata("DIALOG")
		window:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", tile=true, tileSize=32, edgeSize=32, insets={left=8,right=8,top=8,bottom=8}})
		window:EnableMouse(true); window:SetMovable(true); window:RegisterForDrag("LeftButton")
		window:SetScript("OnDragStart", function(self) self:StartMoving() end)
		window:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
		local title=window:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
		title:SetPoint("TOPLEFT",20,-18);title:SetText("DBM-RV UWoW / Status")
		local close=CreateFrame("Button",nil,window,"UIPanelCloseButton");close:SetPoint("TOPRIGHT",-5,-5)
		local scroll=CreateFrame("ScrollFrame",nil,window,"UIPanelScrollFrameTemplate")
		scroll:SetPoint("TOPLEFT",22,-48);scroll:SetPoint("BOTTOMRIGHT",-38,22)
		textBox=CreateFrame("EditBox",nil,scroll);textBox:SetMultiLine(true);textBox:SetAutoFocus(false)
		textBox:SetFontObject(ChatFontNormal);textBox:SetWidth(560);textBox:SetHeight(1000)
		textBox:SetScript("OnEscapePressed",function(self)self:ClearFocus();window:Hide()end)
		scroll:SetScrollChild(textBox)
		table.insert(UISpecialFrames,"DBMRVUWoWCompatStatus")
	end
	textBox:SetText(statusText());textBox:SetCursorPosition(0);window:Show()
end
-- Do not shadow another addon's command, even under a different slash key.
local function commandFree(command)
	for key,value in pairs(_G) do
		if type(key)=="string" and key:match("^SLASH_.*%d+$") and type(value)=="string" and value:lower()==command then return false end
	end
	return true
end
if not SlashCmdList.DBMRVUWoWCompat and not _G.SLASH_DBMRVUWoWCompat1 then
	local command = commandFree("/rvcompat") and "/rvcompat" or (commandFree("/rvuwow") and "/rvuwow")
	if command then
		_G.SLASH_DBMRVUWoWCompat1 = command
		SlashCmdList.DBMRVUWoWCompat = API.Show
		API.command = command
	end
end
installForumMessageHook()
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("PLAYER_REGEN_ENABLED")
frame:SetScript("OnEvent", function() installForumMessageHook(); refresh() end)
refresh()
